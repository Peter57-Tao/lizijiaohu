import './style.css'
import * as THREE from 'three'
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js'
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js'
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js'
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js'
import { FilesetResolver, HandLandmarker } from '@mediapipe/tasks-vision'

const sceneHost = document.querySelector('#scene')
const statusLabel = document.querySelector('#status')
const cameraVideo = document.querySelector('#camera-preview')
const cameraMessage = document.querySelector('#camera-message')
const modeButtons = [...document.querySelectorAll('.mode-button')]

const PARTICLE_COUNT = window.innerWidth < 760 ? 6500 : 11200
const MODEL_URL =
  'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task'
const WASM_URL = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.35/wasm'

const modeConfig = {
  base: { scale: 1, flow: 1.02, spiral: 0.08, core: 1.08, bloom: 0.28 },
  attract: { scale: 0.38, flow: 0.78, spiral: 0.2, core: 1.45, bloom: 0.36 },
  expand: { scale: 2.42, flow: 1.78, spiral: 0.28, core: 0.96, bloom: 0.42 },
  nebula: { scale: 1.14, flow: 1.32, spiral: 0.92, core: 1.12, bloom: 0.34 },
}

const handState = {
  detected: false,
  x: 0,
  y: 0,
  targetX: 0,
  targetY: 0,
  pinch: 0,
  open: 0,
  spinX: 0,
  spinY: 0,
  spinZ: 0,
  lastSeen: 0,
  lastMotionTime: 0,
  prevCenter: null,
  prevIndex: null,
  prevScreenAngle: null,
  prevIndexAngle: null,
  prevPalmAngle: null,
  prevPinchDistance: null,
  prevSpread: null,
}

const particleState = {
  mode: 'base',
  scale: 1,
  targetScale: 1,
  pulse: 0,
  autoRotation: 0,
  inertiaX: 0,
  inertiaY: 0,
  inertiaZ: 0,
}

const clock = new THREE.Clock()
let renderer
let composer
let bloomPass
let scene
let camera
let particleGroup
let particles
let particleMaterial
let particleGeometry
let core
let coreHalo
let starField
let ringA
let ringB
let ringC
let handLandmarker
let cameraStream
let lastVideoTime = -1

const particleData = createParticleData(PARTICLE_COUNT)

bootstrap()

function bootstrap() {
  try {
    createScene()
    createParticles()
    createCore()
    createRings()
    createStarField()
    bindControls()
    renderer.setAnimationLoop(render)
    window.addEventListener('resize', handleResize)
    setStatus('HAND LOST')
    initHandTracking()
  } catch (error) {
    console.error(error)
    setStatus('WEBGL UNAVAILABLE')
    cameraMessage.textContent = '当前浏览器无法启动 3D 渲染。'
  }
}

function createScene() {
  scene = new THREE.Scene()
  scene.background = new THREE.Color(0x02040a)
  scene.fog = new THREE.FogExp2(0x02060d, 0.085)

  camera = new THREE.PerspectiveCamera(52, window.innerWidth / window.innerHeight, 0.1, 80)
  camera.position.set(0, 0.08, 6.82)

  renderer = new THREE.WebGLRenderer({
    alpha: false,
    antialias: true,
    powerPreference: 'high-performance',
  })
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
  renderer.setSize(window.innerWidth, window.innerHeight)
  renderer.outputColorSpace = THREE.SRGBColorSpace
  renderer.toneMapping = THREE.ACESFilmicToneMapping
  renderer.toneMappingExposure = 0.78
  sceneHost.appendChild(renderer.domElement)

  composer = new EffectComposer(renderer)
  composer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
  composer.setSize(window.innerWidth, window.innerHeight)
  composer.addPass(new RenderPass(scene, camera))

  bloomPass = new UnrealBloomPass(
    new THREE.Vector2(window.innerWidth, window.innerHeight),
    0.16,
    0.14,
    0.76,
  )
  composer.addPass(bloomPass)
  composer.addPass(new OutputPass())

  const ambient = new THREE.AmbientLight(0x2f8cff, 0.65)
  const key = new THREE.PointLight(0x4cd8ff, 14, 12)
  key.position.set(2.6, 1.8, 3.2)
  const rim = new THREE.PointLight(0x1b5cff, 9, 14)
  rim.position.set(-3.5, -1.4, -2.2)
  scene.add(ambient, key, rim)

  particleGroup = new THREE.Group()
  scene.add(particleGroup)
}

function createParticles() {
  particleGeometry = new THREE.BufferGeometry()
  particleGeometry.setAttribute('position', new THREE.BufferAttribute(particleData.positions, 3))
  particleGeometry.setAttribute('color', new THREE.BufferAttribute(particleData.colors, 3))
  particleGeometry.setAttribute('aSize', new THREE.BufferAttribute(particleData.sizes, 1))
  particleGeometry.setAttribute('aPhase', new THREE.BufferAttribute(particleData.phases, 1))
  particleGeometry.setAttribute('aBand', new THREE.BufferAttribute(particleData.bands, 1))

  particleMaterial = new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0 },
      uPixelRatio: { value: Math.min(window.devicePixelRatio, 2) },
      uPulse: { value: 0 },
      uOpen: { value: 0 },
      uPinch: { value: 0 },
    },
    vertexShader: `
      attribute float aSize;
      attribute float aPhase;
      attribute float aBand;
      varying vec3 vColor;
      varying float vAlpha;
      uniform float uTime;
      uniform float uPixelRatio;
      uniform float uPulse;
      uniform float uOpen;
      uniform float uPinch;

      void main() {
        vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
        float breathe = 0.94 + sin(uTime * 1.55 + aPhase) * 0.055 + uPulse * 0.09;
        float starPop = 1.0 + uOpen * aBand * (0.72 + step(0.78, fract(sin(aPhase * 41.13) * 43758.5453)) * 1.35);
        float compact = 1.0 - uPinch * 0.18;
        gl_PointSize = aSize * starPop * compact * uPixelRatio * breathe * (210.0 / -mvPosition.z);
        vColor = color;
        vAlpha = 0.44 + sin(uTime * 1.28 + aPhase * 1.7) * 0.1 + uPulse * 0.08 - uOpen * aBand * 0.08;
        gl_Position = projectionMatrix * mvPosition;
      }
    `,
    fragmentShader: `
      varying vec3 vColor;
      varying float vAlpha;

      void main() {
        vec2 center = gl_PointCoord - vec2(0.5);
        float dist = length(center);
        if (dist > 0.5) {
          discard;
        }

        float glow = pow(smoothstep(0.5, 0.0, dist), 1.75);
        float spark = smoothstep(0.18, 0.0, dist);
        float needle = smoothstep(0.055, 0.0, dist);
        vec3 color = vColor * (0.88 + spark * 0.55 + needle * 0.35);
        gl_FragColor = vec4(color, (glow * 0.58 + spark * 0.12) * vAlpha);
      }
    `,
    transparent: true,
    depthWrite: false,
    blending: THREE.NormalBlending,
    vertexColors: true,
  })

  particles = new THREE.Points(particleGeometry, particleMaterial)
  particles.renderOrder = 1
  particleGroup.add(particles)
}

function createCore() {
  const coreMaterial = new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0 },
      uIntensity: { value: 1 },
    },
    vertexShader: `
      varying vec3 vNormal;
      varying vec3 vWorldPosition;

      void main() {
        vNormal = normalize(normalMatrix * normal);
        vec4 worldPosition = modelMatrix * vec4(position, 1.0);
        vWorldPosition = worldPosition.xyz;
        gl_Position = projectionMatrix * viewMatrix * worldPosition;
      }
    `,
    fragmentShader: `
      varying vec3 vNormal;
      varying vec3 vWorldPosition;
      uniform float uTime;
      uniform float uIntensity;

      void main() {
        vec3 viewDirection = normalize(cameraPosition - vWorldPosition);
        float facing = clamp(dot(normalize(vNormal), viewDirection), 0.0, 1.0);
        float rim = pow(1.0 - facing, 2.35);
        float pulse = 0.92 + sin(uTime * 2.4) * 0.08;
        vec3 deepBlue = vec3(0.0, 0.22, 0.9);
        vec3 cyanBlue = vec3(0.0, 0.76, 1.0);
        vec3 rimBlue = vec3(0.0, 0.42, 1.0);
        vec3 color = mix(deepBlue, cyanBlue, facing * 0.9 + 0.08) * pulse;
        color += rimBlue * rim * 0.36;
        float alpha = (0.56 + facing * 0.32 + rim * 0.16) * uIntensity;
        gl_FragColor = vec4(color, alpha);
      }
    `,
    transparent: true,
    blending: THREE.NormalBlending,
    depthTest: false,
    depthWrite: false,
  })
  core = new THREE.Mesh(new THREE.SphereGeometry(0.42, 64, 64), coreMaterial)
  core.renderOrder = 4
  particleGroup.add(core)

  const haloMaterial = new THREE.MeshBasicMaterial({
    color: 0x008cff,
    transparent: true,
    opacity: 0.16,
    blending: THREE.AdditiveBlending,
    depthTest: false,
    depthWrite: false,
  })
  coreHalo = new THREE.Mesh(new THREE.SphereGeometry(0.76, 64, 64), haloMaterial)
  coreHalo.renderOrder = 3
  particleGroup.add(coreHalo)
}

function createRings() {
  const ringMaterial = new THREE.MeshBasicMaterial({
    color: 0x1de8ff,
    transparent: true,
    opacity: 0.14,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  })
  const geometry = new THREE.TorusGeometry(2.66, 0.0045, 8, 220)

  ringA = new THREE.Mesh(geometry, ringMaterial.clone())
  ringA.rotation.set(Math.PI * 0.48, Math.PI * 0.1, 0)

  ringB = new THREE.Mesh(geometry, ringMaterial.clone())
  ringB.rotation.set(Math.PI * 0.18, Math.PI * 0.58, Math.PI * 0.36)
  ringB.material.opacity = 0.12

  ringC = new THREE.Mesh(geometry, ringMaterial.clone())
  ringC.rotation.set(Math.PI * 0.68, Math.PI * 0.22, Math.PI * 0.72)
  ringC.material.opacity = 0.09

  particleGroup.add(ringA, ringB, ringC)
}

function createStarField() {
  const count = 1800
  const positions = new Float32Array(count * 3)
  const colors = new Float32Array(count * 3)
  const colorA = new THREE.Color(0x0c47ff)
  const colorB = new THREE.Color(0x1fdcff)

  for (let i = 0; i < count; i += 1) {
    const i3 = i * 3
    const radius = 14 + Math.random() * 22
    const theta = Math.random() * Math.PI * 2
    const phi = Math.acos(2 * Math.random() - 1)
    positions[i3] = Math.sin(phi) * Math.cos(theta) * radius
    positions[i3 + 1] = Math.sin(phi) * Math.sin(theta) * radius
    positions[i3 + 2] = Math.cos(phi) * radius - 5

    const color = colorA.clone().lerp(colorB, Math.random() * 0.62)
    colors[i3] = color.r
    colors[i3 + 1] = color.g
    colors[i3 + 2] = color.b
  }

  const geometry = new THREE.BufferGeometry()
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3))
  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3))

  starField = new THREE.Points(
    geometry,
    new THREE.PointsMaterial({
      size: 0.027,
      transparent: true,
      opacity: 0.42,
      vertexColors: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    }),
  )
  scene.add(starField)
}

function createParticleData(count) {
  const positions = new Float32Array(count * 3)
  const basePositions = new Float32Array(count * 3)
  const colors = new Float32Array(count * 3)
  const sizes = new Float32Array(count)
  const phases = new Float32Array(count)
  const seeds = new Float32Array(count)
  const radius = new Float32Array(count)
  const bands = new Float32Array(count)

  const colorA = new THREE.Color(0x006dff)
  const colorB = new THREE.Color(0x13cfff)
  const colorC = new THREE.Color(0x2aefff)

  for (let i = 0; i < count; i += 1) {
    const i3 = i * 3
    const direction = randomUnitVector()
    const shellBias = Math.random()
    let particleRadius
    let band = 0

    if (shellBias > 0.86) {
      particleRadius = 2.12 + Math.random() * 0.72
      direction.y *= 0.82 + Math.random() * 0.18
      band = 1
    } else if (shellBias > 0.2) {
      particleRadius = 1.18 + Math.pow(Math.random(), 0.26) * 1.04
      band = 0.32 + Math.random() * 0.26
    } else {
      particleRadius = 0.44 + Math.pow(Math.random(), 0.72) * 0.3
      band = 0.12
    }

    const jitter = (Math.random() - 0.5) * 0.105

    basePositions[i3] = direction.x * (particleRadius + jitter)
    basePositions[i3 + 1] = direction.y * (particleRadius + jitter)
    basePositions[i3 + 2] = direction.z * (particleRadius + jitter)

    positions[i3] = basePositions[i3]
    positions[i3 + 1] = basePositions[i3 + 1]
    positions[i3 + 2] = basePositions[i3 + 2]

    const mix = Math.random()
    const color = colorA.clone().lerp(colorB, Math.min(0.78, mix * 0.82))
    if (shellBias > 0.86 || mix > 0.92) {
      color.lerp(colorC, 0.12 + Math.random() * 0.2)
    }
    colors[i3] = color.r
    colors[i3 + 1] = color.g
    colors[i3 + 2] = color.b

    sizes[i] = 0.32 + Math.random() * 0.68 + (Math.random() > 0.975 ? 0.58 : 0) - band * 0.05
    phases[i] = Math.random() * Math.PI * 2
    seeds[i] = Math.random()
    radius[i] = particleRadius
    bands[i] = band
  }

  return {
    positions,
    basePositions,
    colors,
    sizes,
    phases,
    seeds,
    radius,
    bands,
  }
}

function randomUnitVector() {
  const z = Math.random() * 2 - 1
  const angle = Math.random() * Math.PI * 2
  const root = Math.sqrt(1 - z * z)

  return {
    x: root * Math.cos(angle),
    y: root * Math.sin(angle),
    z,
  }
}

function bindControls() {
  modeButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const nextMode = button.dataset.mode

      if (nextMode === 'reset') {
        resetExperience()
        return
      }

      setMode(nextMode)
    })
  })
}

function setMode(nextMode) {
  if (!modeConfig[nextMode]) {
    return
  }

  particleState.mode = nextMode
  modeButtons.forEach((button) => {
    button.classList.toggle('is-active', button.dataset.mode === nextMode)
  })
}

function resetExperience() {
  setMode('base')
  particleState.scale = 1
  particleState.targetScale = 1
  particleState.autoRotation = 0
  handState.x = 0
  handState.y = 0
  handState.targetX = 0
  handState.targetY = 0
  handState.pinch = 0
  handState.open = 0
  handState.spinX = 0
  handState.spinY = 0
  handState.spinZ = 0
  handState.lastMotionTime = 0
  handState.prevCenter = null
  handState.prevIndex = null
  handState.prevScreenAngle = null
  handState.prevIndexAngle = null
  handState.prevPalmAngle = null
  handState.prevPinchDistance = null
  handState.prevSpread = null
  particleState.inertiaX = 0
  particleState.inertiaY = 0
  particleState.inertiaZ = 0
  particleGroup.rotation.set(0, 0, 0)
}

async function initHandTracking() {
  if (!navigator.mediaDevices?.getUserMedia) {
    setStatus('CAMERA UNAVAILABLE')
    cameraMessage.textContent = '当前浏览器不支持摄像头访问，粒子将自动运行。'
    return
  }

  try {
    cameraStream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: {
        facingMode: 'user',
        width: { ideal: 640 },
        height: { ideal: 480 },
      },
    })
    cameraVideo.srcObject = cameraStream
    await cameraVideo.play()
    cameraVideo.parentElement.classList.add('is-live')
    cameraMessage.textContent = 'LIVE'
  } catch (error) {
    console.error(error)
    setStatus('CAMERA UNAVAILABLE')
    cameraMessage.textContent = cameraErrorText(error)
    return
  }

  try {
    setStatus('MODEL LOADING')
    const vision = await FilesetResolver.forVisionTasks(WASM_URL)
    handLandmarker = await HandLandmarker.createFromOptions(vision, {
      baseOptions: {
        modelAssetPath: MODEL_URL,
        delegate: 'GPU',
      },
      runningMode: 'VIDEO',
      numHands: 1,
      minHandDetectionConfidence: 0.56,
      minHandPresenceConfidence: 0.54,
      minTrackingConfidence: 0.52,
    })

    setStatus('HAND LOST')
    detectHands()
  } catch (error) {
    console.error(error)
    setStatus('TRACKING UNAVAILABLE')
    cameraMessage.textContent = '摄像头已开启，手势模型暂时加载失败。'
  }
}

function detectHands() {
  if (!handLandmarker || cameraVideo.readyState < HTMLMediaElement.HAVE_CURRENT_DATA) {
    requestAnimationFrame(detectHands)
    return
  }

  if (cameraVideo.currentTime !== lastVideoTime) {
    lastVideoTime = cameraVideo.currentTime
    const results = handLandmarker.detectForVideo(cameraVideo, performance.now())
    updateHandState(results)
  }

  requestAnimationFrame(detectHands)
}

function updateHandState(results) {
  const landmarks = results?.landmarks?.[0]
  const now = performance.now()

  if (!landmarks) {
    if (now - handState.lastSeen > 520) {
      handState.detected = false
      handState.pinch = approach(handState.pinch, 0, 0.16)
      handState.open = approach(handState.open, 0, 0.16)
      handState.prevCenter = null
      handState.prevIndex = null
      handState.prevScreenAngle = null
      handState.prevIndexAngle = null
      handState.prevPalmAngle = null
      handState.prevPinchDistance = null
      handState.prevSpread = null
      handState.lastMotionTime = 0
      setStatus('HAND LOST')
    }
    return
  }

  const previousMotionTime = handState.lastMotionTime || now
  const dt = THREE.MathUtils.clamp((now - previousMotionTime) / 1000, 0.016, 0.08)
  handState.detected = true
  handState.lastSeen = now
  handState.lastMotionTime = now

  const center = palmCenter(landmarks)
  const palmSize = Math.max(distance2D(landmarks[5], landmarks[17]), 0.045)
  const open = openPalmScore(landmarks, center, palmSize)
  const pointerControl = getPointerControl(landmarks, palmSize, open)
  const pointer = pointerControl.point
  const screenAngle = Math.atan2(pointer.y - 0.5, pointer.x - 0.5)
  const indexAngle = Math.atan2(pointer.y - center.y, pointer.x - center.x)
  const palmAngle = Math.atan2(landmarks[17].y - landmarks[5].y, landmarks[17].x - landmarks[5].x)

  const steeringPoint = pointerControl.strength > 0.2 ? pointer : center
  handState.targetX = THREE.MathUtils.clamp((0.5 - steeringPoint.x) * 2.65, -1, 1)
  handState.targetY = THREE.MathUtils.clamp((0.5 - steeringPoint.y) * 2.4, -1, 1)
  handState.x = approach(handState.x, handState.targetX, 0.28)
  handState.y = approach(handState.y, handState.targetY, 0.28)

  const pinchDistance = distance2D(landmarks[4], landmarks[8]) / palmSize
  const pinch = THREE.MathUtils.clamp((0.84 - pinchDistance) / 0.4, 0, 1)
  const spread = open
  updateGestureMomentum(
    center,
    pointer,
    pointerControl.strength,
    screenAngle,
    indexAngle,
    palmAngle,
    dt,
    pinch,
    open,
    pinchDistance,
    spread,
  )

  handState.pinch = approach(handState.pinch, pinch, 0.32)
  handState.open = approach(handState.open, open * (1 - handState.pinch * 0.86), 0.26)

  if (handState.pinch > 0.58) {
    setStatus('PINCH')
  } else if (handState.open > 0.42) {
    setStatus('EXPAND')
  } else {
    setStatus('HAND TRACKING')
  }
}

function updateGestureMomentum(
  center,
  pointer,
  controlStrength,
  screenAngle,
  indexAngle,
  palmAngle,
  dt,
  pinch,
  open,
  pinchDistance,
  spread,
) {
  const pinchRate =
    handState.prevPinchDistance === null ? 0 : Math.abs(pinchDistance - handState.prevPinchDistance) / dt
  const spreadRate = handState.prevSpread === null ? 0 : Math.abs(spread - handState.prevSpread) / dt
  const scaleActivity = THREE.MathUtils.clamp(pinch * 0.92 + pinchRate * 0.68 + spreadRate * 0.1, 0, 1)
  const spinGate = THREE.MathUtils.clamp((1 - scaleActivity) * (0.32 + controlStrength * 0.92), 0.06, 1)

  if (handState.prevCenter && handState.prevIndex) {
    const pointerVX = ((pointer.x - handState.prevIndex.x) * 0.86 + (center.x - handState.prevCenter.x) * 0.14) / dt
    const pointerVY = ((pointer.y - handState.prevIndex.y) * 0.86 + (center.y - handState.prevCenter.y) * 0.14) / dt
    const flick = Math.hypot(pointerVX, pointerVY)

    if (flick > 0.14 && spinGate > 0.1) {
      const boost = THREE.MathUtils.clamp((flick - 0.14) / 0.86, 0, 1)
      const intentionalSwipe = Math.pow(boost, 1.15)
      handState.spinY = clampSpin(handState.spinY * 0.28 - pointerVX * 38 * intentionalSwipe * spinGate, 64)
      handState.spinX = clampSpin(handState.spinX * 0.28 - pointerVY * 21 * intentionalSwipe * spinGate, 42)
    }
  }

  if (handState.prevScreenAngle !== null) {
    const indexRadius = Math.hypot(pointer.x - 0.5, pointer.y - 0.5)
    const screenTurn = normalizeAngleDelta(screenAngle - handState.prevScreenAngle) / dt

    if (indexRadius > 0.08 && Math.abs(screenTurn) > 0.62 && spinGate > 0.1) {
      const turnBoost = THREE.MathUtils.clamp((Math.abs(screenTurn) - 0.62) / 4.8, 0, 1)
      handState.spinZ = clampSpin(handState.spinZ * 0.24 + screenTurn * 4.8 * turnBoost * spinGate, 42)
      handState.spinX = clampSpin(handState.spinX + Math.sin(screenAngle) * Math.abs(screenTurn) * 1.45 * turnBoost * spinGate, 32)
      handState.spinY = clampSpin(handState.spinY - Math.cos(screenAngle) * Math.abs(screenTurn) * 1.15 * turnBoost * spinGate, 46)
    }
  }

  if (handState.prevIndexAngle !== null && handState.prevPalmAngle !== null) {
    const indexTurn = normalizeAngleDelta(indexAngle - handState.prevIndexAngle) / dt
    const palmTurn = normalizeAngleDelta(palmAngle - handState.prevPalmAngle) / dt
    const turnVelocity = indexTurn * 0.46 + palmTurn * 0.34

    if (Math.abs(turnVelocity) > 1.05 && spinGate > 0.28) {
      const turnBoost = THREE.MathUtils.clamp((Math.abs(turnVelocity) - 1.05) / 6.4, 0, 1)
      handState.spinZ = clampSpin(handState.spinZ * 0.3 + turnVelocity * 1.1 * turnBoost * spinGate, 30)
      handState.spinY = clampSpin(handState.spinY + turnVelocity * 0.32 * turnBoost * spinGate, 46)
    }
  }

  handState.prevCenter = { x: center.x, y: center.y }
  handState.prevIndex = { x: pointer.x, y: pointer.y }
  handState.prevScreenAngle = screenAngle
  handState.prevIndexAngle = indexAngle
  handState.prevPalmAngle = palmAngle
  handState.prevPinchDistance = pinchDistance
  handState.prevSpread = spread
}

function palmCenter(landmarks) {
  const ids = [0, 5, 9, 13, 17]
  const sum = ids.reduce(
    (acc, id) => {
      acc.x += landmarks[id].x
      acc.y += landmarks[id].y
      return acc
    },
    { x: 0, y: 0 },
  )

  return {
    x: sum.x / ids.length,
    y: sum.y / ids.length,
  }
}

function getPointerControl(landmarks, palmSize, open) {
  const indexScore = fingerExtensionScore(landmarks, 8, 5, palmSize)
  const middleScore = fingerExtensionScore(landmarks, 12, 9, palmSize)
  const twoFingerGap = distance2D(landmarks[8], landmarks[12]) / palmSize
  const twoFinger = indexScore > 0.34 && middleScore > 0.34 && twoFingerGap < 0.78
  const indexOnly = indexScore > 0.18

  const point = twoFinger
    ? {
        x: (landmarks[8].x + landmarks[12].x) * 0.5,
        y: (landmarks[8].y + landmarks[12].y) * 0.5,
      }
    : { x: landmarks[8].x, y: landmarks[8].y }

  const pointerScore = twoFinger
    ? Math.min(1, (indexScore + middleScore) * 0.5 + 0.32)
    : indexOnly
      ? Math.min(1, indexScore + 0.18)
      : 0

  return {
    point,
    strength: THREE.MathUtils.clamp(Math.max(pointerScore, open * 0.72), 0, 1),
  }
}

function fingerExtensionScore(landmarks, tipId, mcpId, palmSize) {
  const wrist = landmarks[0]
  const tipDistance = distance2D(wrist, landmarks[tipId])
  const baseDistance = distance2D(wrist, landmarks[mcpId])
  return THREE.MathUtils.clamp((tipDistance - baseDistance * 1.02) / (palmSize * 0.54), 0, 1)
}

function openPalmScore(landmarks, center, palmSize) {
  const fingerPairs = [
    [8, 5],
    [12, 9],
    [16, 13],
    [20, 17],
  ]
  const fingerScores = fingerPairs.map(([tipId, mcpId]) => {
    return fingerExtensionScore(landmarks, tipId, mcpId, palmSize)
  })
  const averageExtension = fingerScores.reduce((sum, value) => sum + value, 0) / fingerScores.length
  const weakestFinger = Math.min(...fingerScores)
  const fingerSpan = distance2D(landmarks[8], landmarks[20]) / palmSize
  const spreadScore = THREE.MathUtils.clamp((fingerSpan - 1.05) / 0.72, 0, 1)
  const thumbAway = THREE.MathUtils.clamp((distance2D(landmarks[4], landmarks[8]) / palmSize - 0.92) / 0.42, 0, 1)
  const palmFacing = THREE.MathUtils.clamp((distance2D(center, landmarks[12]) / palmSize - 0.72) / 0.38, 0, 1)

  return THREE.MathUtils.clamp(
    (averageExtension * 0.38 + weakestFinger * 0.34 + spreadScore * 0.18 + palmFacing * 0.1) * thumbAway,
    0,
    1,
  )
}

function distance2D(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y)
}

function normalizeAngleDelta(delta) {
  return Math.atan2(Math.sin(delta), Math.cos(delta))
}

function clampSpin(value, limit) {
  return THREE.MathUtils.clamp(value, -limit, limit)
}

function cameraErrorText(error) {
  if (error?.name === 'NotAllowedError') {
    return '摄像头权限未开启，粒子将以自动模式运行。'
  }

  if (error?.name === 'NotFoundError' || error?.name === 'OverconstrainedError') {
    return '未检测到可用摄像头，粒子将以自动模式运行。'
  }

  return '摄像头暂时不可用，粒子将以自动模式运行。'
}

function setStatus(text) {
  if (statusLabel.textContent !== text) {
    statusLabel.textContent = text
  }
}

function render() {
  const delta = clock.getDelta()
  const elapsed = clock.elapsedTime
  const config = modeConfig[particleState.mode]

  particleState.targetScale = resolveScale(config)
  particleState.scale = approach(particleState.scale, particleState.targetScale, 0.12)
  particleState.pulse = approach(
    particleState.pulse,
    handState.pinch > 0.5 || handState.open > 0.4 ? 1 : 0,
    0.06,
  )

  updateParticles(elapsed, config)
  updateSceneMotion(elapsed, delta, config)
  updateCore(elapsed, config)
  updatePostProcessing(config)

  particleMaterial.uniforms.uTime.value = elapsed
  particleMaterial.uniforms.uPulse.value = particleState.pulse
  particleMaterial.uniforms.uOpen.value = getExpansionLevel()
  particleMaterial.uniforms.uPinch.value = handState.pinch

  composer.render()
}

function resolveScale(config) {
  let scale = config.scale

  if (handState.detected) {
    if (handState.pinch > 0.08) {
      scale = THREE.MathUtils.lerp(scale, 0.16, handState.pinch)
    } else if (handState.open > 0.08) {
      scale = THREE.MathUtils.lerp(scale, 3.05, handState.open)
    }
  }

  return scale
}

function getExpansionLevel() {
  const modeExpansion = particleState.mode === 'expand' ? 0.76 : particleState.mode === 'nebula' ? 0.36 : 0
  return Math.max(handState.open, modeExpansion)
}

function updateParticles(elapsed, config) {
  const positions = particleGeometry.attributes.position.array
  const base = particleData.basePositions
  const phases = particleData.phases
  const seeds = particleData.seeds
  const radii = particleData.radius
  const bands = particleData.bands
  const scale = particleState.scale
  const expansion = getExpansionLevel()
  const handEnergy = handState.pinch * 0.5 + expansion * 0.35

  for (let i = 0; i < PARTICLE_COUNT; i += 1) {
    const i3 = i * 3
    const bx = base[i3]
    const by = base[i3 + 1]
    const bz = base[i3 + 2]
    const phase = phases[i]
    const seed = seeds[i]
    const radius = radii[i]
    const band = bands[i]
    const length = Math.max(0.0001, Math.hypot(bx, by, bz))
    const nx = bx / length
    const ny = by / length
    const nz = bz / length
    const open = expansion
    const pinch = handState.pinch
    const breathe = 1 + Math.sin(elapsed * 1.22 + phase) * (0.018 + handEnergy * 0.018)
    const layerStretch = 1 + open * (band * 1.18 + Math.max(0, band - 0.7) * 0.72 + seed * 0.12)
    const localScale = scale * layerStretch
    const compactRadius = 0.2 + seed * 0.54 + band * 0.08
    const flow = config.flow * (0.022 + seed * 0.034 + band * 0.018) * (1 - pinch * 0.62 + open * 0.28)
    const drift = Math.sin(elapsed * (0.58 + seed * 0.42) + phase + radius) * flow

    let x = THREE.MathUtils.lerp(bx * localScale, nx * compactRadius, pinch) * breathe
    let y = THREE.MathUtils.lerp(by * localScale, ny * compactRadius, pinch) * breathe
    let z = THREE.MathUtils.lerp(bz * localScale, nz * compactRadius, pinch) * breathe

    x += Math.sin(elapsed * 0.76 + phase + by * 1.6) * drift
    y += Math.cos(elapsed * 0.66 + phase + bz * 1.2) * drift
    z += Math.sin(elapsed * 0.72 + phase + bx * 1.4) * drift

    if (band > 0) {
      const orbit = elapsed * (0.22 + seed * 0.18) + phase
      const orbitPush = (0.035 + config.spiral * 0.22 + open * 0.2) * band * (1 - pinch * 0.86)
      x += Math.cos(orbit + by * 0.9) * orbitPush * radius
      z += Math.sin(orbit + bx * 0.9) * orbitPush * radius
      y += Math.sin(orbit * 2 + phase) * orbitPush * 0.34
    }

    if (config.spiral > 0) {
      const angle = Math.atan2(z, x) + elapsed * (0.16 + seed * 0.08) + radius * 0.16
      const arm = Math.sin(angle * 3.2 + radius * 1.7 + elapsed * 0.45) * config.spiral * 0.22 * (1 - pinch * 0.78)
      x += Math.cos(angle) * arm * radius
      z += Math.sin(angle) * arm * radius
      y *= 0.88 + Math.sin(elapsed * 0.32 + phase) * config.spiral * 0.05
    }

    positions[i3] = x
    positions[i3 + 1] = y
    positions[i3 + 2] = z
  }

  particleGeometry.attributes.position.needsUpdate = true
}

function updateSceneMotion(elapsed, delta, config) {
  const expansion = getExpansionLevel()
  const scaleActivity = THREE.MathUtils.clamp(handState.pinch * 0.85, 0, 1)
  const handRotationY = handState.detected ? handState.x * (2.05 - scaleActivity * 0.55) : 0
  const handRotationX = handState.detected ? -handState.y * (1.24 - scaleActivity * 0.34) : Math.sin(elapsed * 0.22) * 0.075
  const autoSpeed = handState.detected ? 0.035 : 0.17
  const spinDamping = Math.pow(handState.detected ? 0.989 - scaleActivity * 0.04 : 0.992, delta * 60)

  particleState.inertiaX += handState.spinX * delta
  particleState.inertiaY += handState.spinY * delta
  particleState.inertiaZ += handState.spinZ * delta

  handState.spinX *= spinDamping
  handState.spinY *= spinDamping
  handState.spinZ *= spinDamping

  particleState.autoRotation += delta * autoSpeed
  particleGroup.rotation.y = approach(
    particleGroup.rotation.y,
    particleState.autoRotation + particleState.inertiaY + handRotationY,
    0.2,
  )
  particleGroup.rotation.x = approach(particleGroup.rotation.x, particleState.inertiaX + handRotationX, 0.18)
  particleGroup.rotation.z =
    particleState.inertiaZ * 0.86 + Math.sin(elapsed * 0.18) * 0.03 + config.spiral * Math.sin(elapsed * 0.24) * 0.06

  particles.rotation.y += delta * (0.028 + config.flow * 0.017 + expansion * 0.028 + Math.abs(handState.spinY) * 0.024)
  particles.rotation.x += delta * (0.008 + handState.pinch * 0.006 + Math.abs(handState.spinX) * 0.02)

  ringA.rotation.z += delta * (0.16 + config.spiral * 0.18)
  ringB.rotation.x -= delta * 0.11
  ringB.rotation.y += delta * 0.08
  ringC.rotation.z -= delta * 0.07

  starField.rotation.y += delta * 0.006
  starField.rotation.x = Math.sin(elapsed * 0.06) * 0.035
}

function updateCore(elapsed, config) {
  const expansion = getExpansionLevel()
  const gestureBoost = handState.pinch * 0.2 + expansion * 0.1
  const corePulse = 1 + Math.sin(elapsed * 2.1) * 0.07 + particleState.pulse * 0.1 + gestureBoost
  core.scale.setScalar(corePulse * config.core)
  core.material.uniforms.uTime.value = elapsed
  core.material.uniforms.uIntensity.value = 0.86 + particleState.pulse * 0.08 + handState.pinch * 0.08

  const haloPulse = 1.02 + Math.sin(elapsed * 1.35) * 0.12 + (particleState.scale - 1) * 0.08
  coreHalo.scale.setScalar(Math.max(0.72, haloPulse))
  coreHalo.material.opacity = 0.08 + Math.sin(elapsed * 1.8) * 0.018 + particleState.pulse * 0.045 + expansion * 0.026

  ringA.material.opacity = 0.12 + Math.sin(elapsed * 1.4) * 0.035 + config.spiral * 0.05
  ringB.material.opacity = 0.08 + Math.sin(elapsed * 1.1 + 1.4) * 0.03
  ringC.material.opacity = 0.06 + Math.sin(elapsed * 1.2 + 2.2) * 0.025
}

function updatePostProcessing(config) {
  if (!bloomPass) {
    return
  }

  const expansion = getExpansionLevel()
  const gestureBoost = handState.pinch * 0.12 + expansion * 0.08
  bloomPass.strength = approach(bloomPass.strength, config.bloom * 0.46 + particleState.pulse * 0.08 + gestureBoost, 0.08)
  bloomPass.radius = approach(bloomPass.radius, 0.2 + config.spiral * 0.05 + expansion * 0.04, 0.06)
  bloomPass.threshold = approach(bloomPass.threshold, handState.pinch > 0.4 ? 0.46 : 0.58, 0.05)
}

function approach(current, target, amount) {
  return current + (target - current) * amount
}

function handleResize() {
  camera.aspect = window.innerWidth / window.innerHeight
  camera.updateProjectionMatrix()
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
  renderer.setSize(window.innerWidth, window.innerHeight)
  composer?.setPixelRatio(Math.min(window.devicePixelRatio, 2))
  composer?.setSize(window.innerWidth, window.innerHeight)
  bloomPass?.setSize(window.innerWidth, window.innerHeight)
  particleMaterial.uniforms.uPixelRatio.value = Math.min(window.devicePixelRatio, 2)
}

if (import.meta.hot) {
  import.meta.hot.dispose(() => {
    window.removeEventListener('resize', handleResize)
    renderer?.setAnimationLoop(null)
    cameraStream?.getTracks().forEach((track) => track.stop())
    handLandmarker?.close()
    particleGeometry?.dispose()
    particleMaterial?.dispose()
    core?.geometry.dispose()
    core?.material.dispose()
    coreHalo?.geometry.dispose()
    coreHalo?.material.dispose()
    starField?.geometry.dispose()
    starField?.material.dispose()
    ringA?.geometry.dispose()
    ringA?.material.dispose()
    ringB?.material.dispose()
    ringC?.material.dispose()
    composer?.dispose()
    renderer?.dispose()
  })
}
